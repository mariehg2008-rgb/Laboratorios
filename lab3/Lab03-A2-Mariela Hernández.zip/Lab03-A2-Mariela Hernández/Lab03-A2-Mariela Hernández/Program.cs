﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Bienvenido/a, porfavor, ingrese sus datos para el programa");
Console.WriteLine("Ingrese su nombre: ");
string nombre;
nombre = Console.ReadLine();
Console.WriteLine("Ingrese el nombre del curso: ");
string curso;
curso = Console.ReadLine();
Console.WriteLine("Bienvenido/a al curso de " + curso + " ," + nombre + ".");
Console.WriteLine("Esperamos que te guste el programa del curso y que salgas con muchos nuevos conocimientos");
Console.WriteLine("Esfuerzate y veras lo fácil que es");
Console.WriteLine();
Console.WriteLine("Si tienes alguna duda o consulta comunicate al correo electronico de tu asesor");
Console.WriteLine();
Console.WriteLine("Presiona cualquier tecla para salir...");
Console.ReadKey();

